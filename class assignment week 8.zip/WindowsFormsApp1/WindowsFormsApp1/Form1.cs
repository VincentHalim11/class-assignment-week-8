﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {

        List<string> nama = new List<string>();
        int count = 0;
        OpenFileDialog ofd = new OpenFileDialog();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            txt_nama.Enabled = true;
            txt_alamat.Enabled = true;
            txt_telp.Enabled = true;

            btn_lihat.Visible = true;
            btn_simpan.Visible = true;
            btn_prev.Visible = false;
            btn_next.Visible = false;
            btn_kembali.Visible = false;
        }
        private void btn_file_Click(object sender, EventArgs e)
        {
            
            ofd.InitialDirectory = "Y:\\";
            ofd.ShowDialog();

            StreamReader sr = new StreamReader(ofd.FileName);
            string text = sr.ReadLine();
            while(text != null)
            {
                nama.Add(text);
                text = sr.ReadLine();
            }
            sr.Close();
        }


        private void btn_simpan_Click(object sender, EventArgs e)
        {
            nama.Add(txt_nama.Text +";"+txt_alamat.Text+";"+txt_telp.Text);
            StreamWriter sr = new StreamWriter(ofd.FileName);
            for(int i = 0; i< nama.Count; i++)
            {
                sr.WriteLine(nama[i].ToString());
            }
            sr.Close();

        }

        private void btn_lihat_Click(object sender, EventArgs e)
        {
            txt_nama.Enabled = false;
            txt_alamat.Enabled = false;
            txt_telp.Enabled = false;

            btn_lihat.Visible = false;
            btn_simpan.Visible = false;
            btn_prev.Visible = true;
            btn_next.Visible = true;
            btn_kembali.Visible = true;

            StreamReader sr = new StreamReader(ofd.FileName);
            string[] name = nama[0].Split(';');
            txt_nama.Text = name[0];
            txt_alamat.Text = name[1];
            txt_telp.Text = name[2];

            

        }

        private void btn_kembali_Click(object sender, EventArgs e)
        {
            txt_nama.Enabled = true;
            txt_alamat.Enabled = true;
            txt_telp.Enabled = true;

            btn_lihat.Visible = true;
            btn_simpan.Visible = true;
            btn_prev.Visible = false;
            btn_next.Visible = false;
            btn_kembali.Visible = false;
        }

        private void btn_next_Click(object sender, EventArgs e)
        {
            StreamReader sr = new StreamReader(ofd.FileName);
            string[] name = nama[count].Split(';');
            txt_nama.Text = name[0];
            txt_alamat.Text = name[1];
            txt_telp.Text = name[2];
            
            if (count < nama.Count-1)
            {
                count++;
            }


        }

        private void btn_prev_Click(object sender, EventArgs e)
        {
            StreamReader sr = new StreamReader(ofd.FileName);
            string[] name = nama[count].Split(';');
            txt_nama.Text = name[0];
            txt_alamat.Text = name[1];
            txt_telp.Text = name[2];
            count--;

            if (count <= 0 )
            {
                count = 0;
            }
        }
    }
}
