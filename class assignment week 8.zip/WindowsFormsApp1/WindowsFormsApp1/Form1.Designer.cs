﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_simpan = new System.Windows.Forms.Button();
            this.btn_lihat = new System.Windows.Forms.Button();
            this.lbl_nama = new System.Windows.Forms.Label();
            this.lbl_alamat = new System.Windows.Forms.Label();
            this.lbl_telp = new System.Windows.Forms.Label();
            this.txt_nama = new System.Windows.Forms.TextBox();
            this.txt_telp = new System.Windows.Forms.TextBox();
            this.txt_alamat = new System.Windows.Forms.TextBox();
            this.btn_file = new System.Windows.Forms.Button();
            this.btn_prev = new System.Windows.Forms.Button();
            this.btn_next = new System.Windows.Forms.Button();
            this.btn_kembali = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_simpan
            // 
            this.btn_simpan.Location = new System.Drawing.Point(260, 399);
            this.btn_simpan.Name = "btn_simpan";
            this.btn_simpan.Size = new System.Drawing.Size(166, 44);
            this.btn_simpan.TabIndex = 0;
            this.btn_simpan.Text = "Simpan";
            this.btn_simpan.UseVisualStyleBackColor = true;
            this.btn_simpan.Click += new System.EventHandler(this.btn_simpan_Click);
            // 
            // btn_lihat
            // 
            this.btn_lihat.Location = new System.Drawing.Point(450, 399);
            this.btn_lihat.Name = "btn_lihat";
            this.btn_lihat.Size = new System.Drawing.Size(181, 44);
            this.btn_lihat.TabIndex = 1;
            this.btn_lihat.Text = "lihat";
            this.btn_lihat.UseVisualStyleBackColor = true;
            this.btn_lihat.Click += new System.EventHandler(this.btn_lihat_Click);
            // 
            // lbl_nama
            // 
            this.lbl_nama.AutoSize = true;
            this.lbl_nama.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_nama.Location = new System.Drawing.Point(141, 122);
            this.lbl_nama.Name = "lbl_nama";
            this.lbl_nama.Size = new System.Drawing.Size(117, 42);
            this.lbl_nama.TabIndex = 2;
            this.lbl_nama.Text = "Nama";
            // 
            // lbl_alamat
            // 
            this.lbl_alamat.AutoSize = true;
            this.lbl_alamat.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_alamat.Location = new System.Drawing.Point(141, 205);
            this.lbl_alamat.Name = "lbl_alamat";
            this.lbl_alamat.Size = new System.Drawing.Size(129, 42);
            this.lbl_alamat.TabIndex = 3;
            this.lbl_alamat.Text = "alamat";
            // 
            // lbl_telp
            // 
            this.lbl_telp.AutoSize = true;
            this.lbl_telp.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_telp.Location = new System.Drawing.Point(141, 284);
            this.lbl_telp.Name = "lbl_telp";
            this.lbl_telp.Size = new System.Drawing.Size(149, 42);
            this.lbl_telp.TabIndex = 4;
            this.lbl_telp.Text = "No Telp";
            // 
            // txt_nama
            // 
            this.txt_nama.Location = new System.Drawing.Point(314, 130);
            this.txt_nama.Name = "txt_nama";
            this.txt_nama.Size = new System.Drawing.Size(408, 31);
            this.txt_nama.TabIndex = 5;
            // 
            // txt_telp
            // 
            this.txt_telp.Location = new System.Drawing.Point(314, 296);
            this.txt_telp.Name = "txt_telp";
            this.txt_telp.Size = new System.Drawing.Size(408, 31);
            this.txt_telp.TabIndex = 6;
            // 
            // txt_alamat
            // 
            this.txt_alamat.Location = new System.Drawing.Point(314, 217);
            this.txt_alamat.Name = "txt_alamat";
            this.txt_alamat.Size = new System.Drawing.Size(408, 31);
            this.txt_alamat.TabIndex = 7;
            // 
            // btn_file
            // 
            this.btn_file.Location = new System.Drawing.Point(884, 81);
            this.btn_file.Name = "btn_file";
            this.btn_file.Size = new System.Drawing.Size(181, 44);
            this.btn_file.TabIndex = 8;
            this.btn_file.Text = "File";
            this.btn_file.UseVisualStyleBackColor = true;
            this.btn_file.Click += new System.EventHandler(this.btn_file_Click);
            // 
            // btn_prev
            // 
            this.btn_prev.Location = new System.Drawing.Point(260, 489);
            this.btn_prev.Name = "btn_prev";
            this.btn_prev.Size = new System.Drawing.Size(166, 44);
            this.btn_prev.TabIndex = 9;
            this.btn_prev.Text = "Prev";
            this.btn_prev.UseVisualStyleBackColor = true;
            this.btn_prev.Click += new System.EventHandler(this.btn_prev_Click);
            // 
            // btn_next
            // 
            this.btn_next.Location = new System.Drawing.Point(465, 489);
            this.btn_next.Name = "btn_next";
            this.btn_next.Size = new System.Drawing.Size(166, 44);
            this.btn_next.TabIndex = 10;
            this.btn_next.Text = "Next";
            this.btn_next.UseVisualStyleBackColor = true;
            this.btn_next.Click += new System.EventHandler(this.btn_next_Click);
            // 
            // btn_kembali
            // 
            this.btn_kembali.Location = new System.Drawing.Point(675, 489);
            this.btn_kembali.Name = "btn_kembali";
            this.btn_kembali.Size = new System.Drawing.Size(166, 44);
            this.btn_kembali.TabIndex = 11;
            this.btn_kembali.Text = "kembali";
            this.btn_kembali.UseVisualStyleBackColor = true;
            this.btn_kembali.Click += new System.EventHandler(this.btn_kembali_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1104, 745);
            this.Controls.Add(this.btn_kembali);
            this.Controls.Add(this.btn_next);
            this.Controls.Add(this.btn_prev);
            this.Controls.Add(this.btn_file);
            this.Controls.Add(this.txt_alamat);
            this.Controls.Add(this.txt_telp);
            this.Controls.Add(this.txt_nama);
            this.Controls.Add(this.lbl_telp);
            this.Controls.Add(this.lbl_alamat);
            this.Controls.Add(this.lbl_nama);
            this.Controls.Add(this.btn_lihat);
            this.Controls.Add(this.btn_simpan);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_simpan;
        private System.Windows.Forms.Button btn_lihat;
        private System.Windows.Forms.Label lbl_nama;
        private System.Windows.Forms.Label lbl_alamat;
        private System.Windows.Forms.Label lbl_telp;
        private System.Windows.Forms.TextBox txt_nama;
        private System.Windows.Forms.TextBox txt_telp;
        private System.Windows.Forms.TextBox txt_alamat;
        private System.Windows.Forms.Button btn_file;
        private System.Windows.Forms.Button btn_prev;
        private System.Windows.Forms.Button btn_next;
        private System.Windows.Forms.Button btn_kembali;
    }
}

